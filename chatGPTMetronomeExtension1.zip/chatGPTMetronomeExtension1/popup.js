let intervalId = null;
let audioCtx = null;

function playTick() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }

  const oscillator = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  oscillator.type = 'square'; // or 'sine' for softer sound
  oscillator.frequency.value = 1000; // Hz
  gain.gain.setValueAtTime(1, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);

  oscillator.connect(gain);
  gain.connect(audioCtx.destination);

  oscillator.start();
  oscillator.stop(audioCtx.currentTime + 0.05);
}

document.getElementById('start').onclick = () => {
  if (intervalId) return;

  const bpm = parseInt(document.getElementById('bpm').value);
  const interval = 60000 / bpm;

  audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  // Chrome/Safari autoplay policy fix: resume AudioContext on user gesture
  audioCtx.resume().then(() => {
    playTick(); // immediate tick
    intervalId = setInterval(playTick, interval);
  });
};

document.getElementById('stop').onclick = () => {
  clearInterval(intervalId);
  intervalId = null;
};


/*
let intervalId = null;
const bpmInput = document.getElementById('bpm');
const startBtn = document.getElementById('start');
const stopBtn = document.getElementById('stop');
const tick = document.getElementById('tick');
    console.log(bpmInput);


startBtn.addEventListener("click", function() {

   const bpm = bpmInput; // target BPM
    const interval = 60000 / bpm; // ms between ticks
    setInterval(() => {
    tick.currentTime = 0;  // restart from beginning
    tick.play();
    }, interval);
    
});
*/

